from django.shortcuts import render, redirect
from zqmovies import views


def not_found(request, exception):
    return render(request, 'not_found.html',status=404)   