from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import login as lap
from django.contrib.auth import logout as djnago_logouts
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import get_object_or_404
from mymovies.models import *
from django.contrib.auth.decorators import login_required       
import random
# Create your views herdae.
# error handelling

def not_found(request, exception):
    return render(request, 'not_found.html')                                                                                                                                                                                                                       
              
def detailpage(request,slug):
    st = Movie.objects.all()
    episod = Episode.objects.all
    movita = get_object_or_404(Movie, movi_slug=slug)
    al = Movie.objects.all()[:9]
    data = {  
        'episod':episod,  
        'movita': movita,
        'al': al,
        'st': st,
    }
    return render(request, 'detailpage.html', data)
                                                                                                                                                                                                        
def privacy(request):
    return render(request, 'privacy.html')
def contact(request):
    st = Movie.objects.all()[0:10]
    data={
        'st':st
    }
    return render(request, 'contact.html',data)
def user(request):
    return render(request, 'user.html')

def search(request):
    st = Movie.objects.all()[0:10]
     # yahi method hame databse se data get karke deta hai
    servicedata = Movie.objects.all()
    if request.method == "GET":
        ktm = request.GET.get("servicename")
        if ktm != None:
            servicedata = Movie.objects.filter(Movies_tittle__contains=ktm) 
        else:
            return redirect(search)
    data = {
        'st':st,
        'ktm':ktm,
        'servicedata': servicedata,
    }
    return render(request, 'search.html', data)


def term(request):
    return render(request, 'term.html')


def index(request):
    st = Movie.objects.all()[0:10]
    alli = Movie.objects.all()[:40]
    web = Movie.objects.filter(Category__contains='web')[:20]
    data = {
        'st': st,
        'alli': alli,
        'web':web
    }
    return render(request, 'index.html', data)


def login(request):
    if request.method == "POST":
        # Get the post parameters
        username = request.POST['username']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        # check for errorneous input
        try:
            user = User.objects.filter(username=username)
            messages.warning(
                request, "username Already taken. Try with different username.")
            return redirect('login')
        except User.DoesNotExist:
            # Create the user
            myuser = User.objects.create_user(
                username=username, email=email, password=password)
            myuser.first_name = phone
            # myuser.last_name = l_name
            myuser.phone = phone

            myuser.save()
            messages.success(
                request, " Your Account has been successfully created " + username)

            return redirect('index', {'username': username})
    else:
        return render(request, 'login.html')

def web_Series(request,Gener_movi):
    st = Movie.objects.all()[0:10]
    pt =Gener_movi
    fillter = Movie.objects.filter(Gener_slug__icontains=pt)
    data = {    
        'pt':pt,
        'st':st,
        'fillter':fillter
    }
    return render(request, 'web_Series.html',data) 
def base(request):
    Contact = User.objects.all()  # yahi method hame databse se data get karke deta hai
    pt = Movie.objects.all()
    message = 'Save complete'
    print(st)
    data = {
        'Contact': Contact,
        
        'pt': pt,
    }

    return render(request, 'base.html', data)


def singin(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            lap(request, user)
            messages.success(request, "Welcome back! " + username)
            return redirect('/')
        else:
            messages.error(request, "Check your Crdentials!!")
            return redirect('login')

    return render(request, "login.html")


def logout(request):
    djnago_logouts(request)
    messages.success(request, 'you are logout successfully!')
    return redirect('/')


def about(request):
    st = Movie.objects.all()[0:10]
    data={
        'st':st
    }
    return render(request, 'about.html',data)

@login_required(login_url='login')
def inquiry(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        number = request.POST.get('number')
        desc = request.POST.get('desc')
        addvice = request.POST.get('addvice')

        content = User_messege(name=name, email=email,number=number, desc=desc, addvice=addvice)
        content.save()
        print(content)
        messages.success(request, 'Thankyou ' + name +
                         '  for Contacting us, your quiry will recived we will reply in 1 hour')
        return redirect('/')
        # thank = True
    return render(request, 'about.html')
