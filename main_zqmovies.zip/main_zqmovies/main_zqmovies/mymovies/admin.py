from django.contrib import admin
from mymovies.models import *

# Register your models here.
class main(admin.ModelAdmin):
    fields = ('Category','Movies_tittle','trailer','myurl','server_1','Cast','Movies_img','Mov_Description','Gener','Gener_slug','producr','Imdb','Timing','quilety','Year')

admin.site.site_header = "The ZQMOVIES"
admin.site.index_title = "The ZQMOVIES Administration"
admin.site.site_title = "The ZQMOVIES Admin"

admin.site.register(Movie, main)
admin.site.register(User_messege)
admin.site.register(Episode)
